# Extract only fields needed for sample identity, stage and covariates.
# The published phyloseq object is read as data; no author scripts are executed.
# Access its list storage to avoid requiring a phyloseq installation.
args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args)) args[[1]] else "ADMetaData/reference/gmrepo/processed/2026-10-09-v1"
x <- readRDS(file.path(root, "raw/papers/PRJEB59009_stool_source.rds"))
d <- unclass(attr(x, "sam_data"))
keep <- c("Material", "Group", "Diagnose", "patient_id.x", "Geschlecht", "Alter", "BMI")
out <- data.frame(lapply(keep, function(k) d[[k]]), check.names = FALSE)
names(out) <- keep
out$ena_sample_alias <- attr(d, "row.names")
dir.create(file.path(root, "evidence"), showWarnings = FALSE)
write.table(out, file.path(root, "evidence/PRJEB59009_author_metadata.tsv"), sep = "\t", quote = TRUE, row.names = FALSE, na = "")
cat("Author stool metadata:", nrow(out), "rows\n")
